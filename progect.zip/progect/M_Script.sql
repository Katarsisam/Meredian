create database testX_machina;
use testX_machina;
create table Organization_(
Reg_number int primary key auto_increment,
Org_name varchar(50) unique,
Link varchar(100) default '-',
Phone varchar(50) default '-',
FIO_Dir varchar(50) default '-');

create table User_(
Unique_ID int primary key auto_increment,
Org_name varchar(50), 
First_name varchar(50) not null,
Name_ varchar(50) not null,
Login varchar(20) not null,
Password_ varchar(20),
Role_ varchar(20) not null,
foreign key(Org_name) references Organization_(Org_name));

create table Parents_pers_info(
ID int primary key auto_increment,
First_name varchar(50) not null,
Name_ varchar(50) not null,
Second_name varchar(50) default '-',
Phone varchar(50) default '-',
Docs blob); 

create table Childs_pers_info(
Sertificate BIGINT primary key auto_increment,
Org_name varchar(50), 
First_name varchar(50) not null,
Name_ varchar(50) not null,
Second_name varchar(50) default '-',
School varchar(50),
Class varchar(2),
Subject_ varchar(50),
Docs blob,
foreign key(Org_name) references Organization_(Org_name));

create table Journal(
Unit_number int primary key auto_increment,
Sertificate BIGINT,
Pr_ID int,
Unique_ID int,
First_name varchar(50),
Subject_ varchar(50),
foreign key(Sertificate) references Childs_pers_info(Sertificate),
foreign key(Pr_ID) references Parents_pers_info(ID),
foreign key(Unique_ID) references User_(Unique_ID))

 