CREATE DATABASE  IF NOT EXISTS `testx_machina` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `testx_machina`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: testx_machina
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `childs_pers_info`
--

DROP TABLE IF EXISTS `childs_pers_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `childs_pers_info` (
  `Sertificate` bigint(20) NOT NULL AUTO_INCREMENT,
  `Org_name` varchar(50) DEFAULT NULL,
  `First_name` varchar(50) NOT NULL,
  `Name_` varchar(50) NOT NULL,
  `Second_name` varchar(50) DEFAULT '-',
  `School` varchar(50) DEFAULT NULL,
  `Class` varchar(2) DEFAULT NULL,
  `Subject_` varchar(50) DEFAULT NULL,
  `Docs` blob,
  PRIMARY KEY (`Sertificate`),
  KEY `Org_name` (`Org_name`),
  CONSTRAINT `childs_pers_info_ibfk_1` FOREIGN KEY (`Org_name`) REFERENCES `organization_` (`org_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `childs_pers_info`
--

LOCK TABLES `childs_pers_info` WRITE;
/*!40000 ALTER TABLE `childs_pers_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `childs_pers_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal`
--

DROP TABLE IF EXISTS `journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal` (
  `Unit_number` int(11) NOT NULL AUTO_INCREMENT,
  `Sertificate` bigint(20) DEFAULT NULL,
  `Pr_ID` int(11) DEFAULT NULL,
  `Unique_ID` int(11) DEFAULT NULL,
  `First_name` varchar(50) DEFAULT NULL,
  `Subject_` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Unit_number`),
  KEY `Sertificate` (`Sertificate`),
  KEY `Pr_ID` (`Pr_ID`),
  KEY `Unique_ID` (`Unique_ID`),
  CONSTRAINT `journal_ibfk_1` FOREIGN KEY (`Sertificate`) REFERENCES `childs_pers_info` (`sertificate`),
  CONSTRAINT `journal_ibfk_2` FOREIGN KEY (`Pr_ID`) REFERENCES `parents_pers_info` (`id`),
  CONSTRAINT `journal_ibfk_3` FOREIGN KEY (`Unique_ID`) REFERENCES `user_` (`unique_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal`
--

LOCK TABLES `journal` WRITE;
/*!40000 ALTER TABLE `journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_`
--

DROP TABLE IF EXISTS `organization_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_` (
  `Reg_number` int(11) NOT NULL AUTO_INCREMENT,
  `Org_name` varchar(50) DEFAULT NULL,
  `Link` varchar(100) DEFAULT '-',
  `Phone` varchar(50) DEFAULT '-',
  `FIO_Dir` varchar(50) DEFAULT '-',
  PRIMARY KEY (`Reg_number`),
  UNIQUE KEY `Org_name` (`Org_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_`
--

LOCK TABLES `organization_` WRITE;
/*!40000 ALTER TABLE `organization_` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parents_pers_info`
--

DROP TABLE IF EXISTS `parents_pers_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parents_pers_info` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `First_name` varchar(50) NOT NULL,
  `Name_` varchar(50) NOT NULL,
  `Second_name` varchar(50) DEFAULT '-',
  `Phone` varchar(50) DEFAULT '-',
  `Docs` blob,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parents_pers_info`
--

LOCK TABLES `parents_pers_info` WRITE;
/*!40000 ALTER TABLE `parents_pers_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `parents_pers_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_`
--

DROP TABLE IF EXISTS `user_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_` (
  `Unique_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Org_name` varchar(50) DEFAULT NULL,
  `First_name` varchar(50) NOT NULL,
  `Name_` varchar(50) NOT NULL,
  `Login` varchar(20) NOT NULL,
  `Password_` varchar(20) DEFAULT NULL,
  `Role_` varchar(20) NOT NULL,
  PRIMARY KEY (`Unique_ID`),
  KEY `Org_name` (`Org_name`),
  CONSTRAINT `user__ibfk_1` FOREIGN KEY (`Org_name`) REFERENCES `organization_` (`org_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_`
--

LOCK TABLES `user_` WRITE;
/*!40000 ALTER TABLE `user_` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-02  3:24:40
