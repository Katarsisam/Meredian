﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace interF
{
    public partial class Form1 : Form
    {
        bool state = false;

        public Form1()
        {
            InitializeComponent();
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            state = !state;
            timer1.Enabled = true;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            switch (state)
            {
                case true:
                    {
                        button6.Text = "<";
                        while (Width != 1100)
                            Width += 5;
                        
                        break;
                    }
                case false:
                    {

                        button6.Text = ">";
                        while (Width != 840)
                            Width -= 5;
                       
                        break;
                    }
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            tableLayoutPanel3.Visible = false;
            groupBox1.Visible = false;
            panel1.Visible = true; 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Width = 840;
            Height = 550;
            tableLayoutPanel1.Height = Height;
            panel1.Visible = false;
            dataGridView1.Location = new Point(pictureBox2.Width + 15, pictureBox2.Location.Y+5);
            dataGridView1.Width = Width - pictureBox3.Width - button6.Width*2-5;
            dataGridView1.Height = tableLayoutPanel1.Height - pictureBox7.Height - 10;
            groupBox1.Location = new Point(tableLayoutPanel2.Location.X, dataGridView1.Location.Y);
            groupBox1.Width = 250;
            groupBox1.Height = dataGridView1.Height;
            tableLayoutPanel3.Width = dataGridView1.Width-10;
            tableLayoutPanel3.Location = new Point(dataGridView1.Location.X, dataGridView1.Location.Y + dataGridView1.Height + 5);
            panel1.Size = dataGridView1.Size;
            toolTip1.SetToolTip(pictureBox1, "Выход");
        }
    }
}
